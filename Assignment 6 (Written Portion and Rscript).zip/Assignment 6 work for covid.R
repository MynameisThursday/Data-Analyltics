#use this to clean up cov2 datasets
library(ggfortify)
library("e1071")
library("ggplot2")
library("class")

dataset.control <- t(Proteomics_Control_RolledUp)
colnames(dataset.control) <- dataset.control[1,]
dataset.control <- dataset.control[-1,]
dataset.control <-as.data.frame(dataset.control)
dataset.control$Treatment <- "Control"


dataset.cov1 <- t(Proteomics_CoV1_RolledUp)
colnames(dataset.cov1) <- dataset.cov1[1,]
dataset.cov1 <- dataset.cov1[-1,]
dataset.cov1 <-as.data.frame(dataset.cov1)
dataset.cov1$Treatment <- "Cov1"

dataset.cov2 <- t(Proteomics_CoV2_RolledUp)
colnames(dataset.cov2) <- dataset.cov2[1,]
dataset.cov2 <- dataset.cov2[-1,]
dataset.cov2 <-as.data.frame(dataset.cov2)
library(tidyverse)

pControl <- Proteomics_Control_RolledUp


pCov1 <- Proteomics_CoV1_RolledUp


pCov2 <- Proteomics_CoV2_RolledUp



#Inner merges to create single data frame, merged by protein name code
mergeCols <- c("Protein")
inner <- merge(pControl, pCov1, by = mergeCols)

mergeCols2 <- c("Protein")
full.set <- merge(inner, pCov2, by = mergeCols2)

### Control columns are labeled with x, Cov1 treatment labeled with y, Cov2 treatment is unlabeled




## Exploratory analysis (box plots/histograms)
X20_1x <- full.set$X20_1.x
X20_1y <- full.set$X20_1.y
X20_1 <- full.set$X20_1
boxplot(X20_1x,X20_1y,X20_1, names = c("Control","Cov1","Cov2"))
hist(X20_1x)
hist(X20_1y)
hist(X20_1)

## Dataset fixing for Knn
full.K <- t(full.set)
colnames(full.K) <- full.K[1,]
full.K <- full.K[-1,]


full.K <- as.data.frame(full.K)
full.K$Treatment <- NA
full.K$Treatment[which(grepl(".x",row.names(full.K)))] <- "Control"
full.K$Treatment[which(grepl(".y",row.names(full.K)))] <- "Cov1"
full.K$Treatment[which(is.na(full.K$Treatment))] <- "Cov2"

full.sample <- full.K[,c(7096,4,5,6,708,709,7010,1412,1413,1414,2116,2117,2118,2820,2821,2822,3524,3525,3525,4228,4229,4230,4932,4933,4934,5636,5637,5638,6340,6341,6342)]

# running knn on full sample data set

## number of rows
n = nrow(full.sample)

## training set indexes
train.indexes <- sample(n,n*.7)

## create training/test sets
sample.train <-full.sample[train.indexes,]
sample.test <-full.sample[-train.indexes,]

sqrt(44)
k=7
KNNpred <- knn(train = sample.train[2:30], test = sample.test[2:30], cl = sample.train$Treatment, k = k)

## evaluate
contingency.table <- table(Actual=KNNpred, Predicted = sample.test$Treatment, dnn=list('predicted','actual'))

print(contingency.table)

contingency.matrix = as.matrix(contingency.table)

sum(diag(contingency.matrix))/length(sample.test$Treatment)

## run text with multiple k values
accuracy <- c()
ks <- seq(1,7,1)

for (k in ks) {
  
  KNNpred <- knn(train = sample.train[2:30], test = sample.test[2:30], cl = sample.train$Treatment, k = k)
  cm = as.matrix(table(Actual=KNNpred, Predicted = sample.test$Treatment, dnn=list('predicted','actual')))
  
  accuracy <- c(accuracy,sum(diag(cm))/length(sample.test$Treatment)) 
  
}

plot(ks,accuracy,type = "b")

##PCA Analysis
library(ggfortify)

# PCA with full.sample dataset
sample.df <- full.sample
head(sample.df)

# creating another dataframe from full.sample dataset that contains the columns from 2 to 31
sample.x <- sample.df[,2:31]
sample.x[] <- lapply(sample.x,as.numeric)
sample.x

principal_components <- princomp(sample.x, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = full.sample, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)



##redoing Knn with proteins that follow principle component 1

full.new <- full.sample[,c(1,10,13,17,23,24,29)]

# running knn on full sample data set

## number of rows
n2 = nrow(full.new)

## training set indexes
train.indexes2 <- sample(n2,n2*.7)

## create training/test sets
sample.train2 <-full.new[train.indexes2,]
sample.test2 <-full.new[-train.indexes2,]

sqrt(44)
k=7
KNNpred <- knn(train = sample.train2[2:7], test = sample.test2[2:7], cl = sample.train2$Treatment, k = k)

## evaluate
contingency.table <- table(Actual=KNNpred, Predicted = sample.test2$Treatment, dnn=list('predicted','actual'))

print(contingency.table)

contingency.matrix = as.matrix(contingency.table)

sum(diag(contingency.matrix))/length(sample.test2$Treatment)

## run text with multiple k values
accuracy <- c()
ks <- seq(1,7,1)

for (k in ks) {
  
  KNNpred <- knn(train = sample.train2[2:7], test = sample.test2[2:7], cl = sample.train2$Treatment, k = k)
  cm = as.matrix(table(Actual=KNNpred, Predicted = sample.test2$Treatment, dnn=list('predicted','actual')))
  
  accuracy <- c(accuracy,sum(diag(cm))/length(sample.test2$Treatment)) 
  
}

plot(ks,accuracy,type = "b")

#new application of model shows expected dip in expected accuracy (94%-84%)

#attempting to train knn on whole (full.k) dataset

nk = nrow(full.K)

## training set indexes
train.indexesk <- sample(nk,nk*.7)

## create training/test sets
sample.traink <-full.K[train.indexesk,]
sample.testk <-full.K[-train.indexesk,]

sqrt(44)
k=7
KNNpred.new <- knn(train = sample.train2[2:7], test = sample.testk[1:6], cl = sample.traink$Treatment, k = k)

## evaluate
contingency.table <- table(Actual=KNNpred.new, Predicted = sample.test2$Treatment, dnn=list('predicted','actual'))

print(contingency.table)

contingency.matrix = as.matrix(contingency.table)

sum(diag(contingency.matrix))/length(sample.test2$Treatment)

## applying PCA based model to new subset of full.k (all proteins and treatment) decreased accuracy from 80-90% to 21% (not as accurate)

## run text with multiple k values
accuracy <- c()
ks <- seq(1,7,1)

for (k in ks) {
  
  KNNpred2 <- knn(train = sample.train2[2:7], test = sample.testk[1:6], cl = sample.train2$Treatment, k = k)
  cm = as.matrix(table(Actual=KNNpred2, Predicted = sample.test2$Treatment, dnn=list('predicted','actual')))
  
  accuracy <- c(accuracy,sum(diag(cm))/length(sample.test2$Treatment)) 
  
}

plot(ks,accuracy,type = "b")

#three nearest neighbors still good but less accurate, PCA was over fitted 

### Redo PCA for 10% of the full dataset 

set.seed(123)  # For reproducibility

# Calculate 10% of the total number of columns
num_columns <- ncol(full.K)
subset_size <- ceiling(0.1 * num_columns)

# Randomly sample 10% of the column indices
subset_columns <- sample(seq_len(num_columns), subset_size)

# Create the subset of the data
subset_full.k <- full.K[, subset_columns]

# Inspect the result
dim(subset_full.k)  # Should show 100 rows and ~700 columns

#we just created a subset with 10% of the full.k data 

subset_full.K <- as.data.frame(subset_full.k)
subset_full.K$Treatment <- NA
subset_full.K$Treatment[which(grepl(".x",row.names(subset_full.K)))] <- "Control"
subset_full.K$Treatment[which(grepl(".y",row.names(subset_full.K)))] <- "Cov1"
subset_full.K$Treatment[which(is.na(subset_full.K$Treatment))] <- "Cov2"

#we just added Treatment to the subset of full.K so we can run knn and pca

#running pca on the 10%

# PCA with full.sample dataset
subset.df <- subset_full.K
head(subset.df)

# creating another dataframe from full.sample dataset that contains the columns from 2 to 31
subset.x <- subset.df[,1:62]
subset.x[] <- lapply(subset.x,as.numeric)
subset.x

principal_components <- princomp(subset.x, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)
#problem we can only run the pca on 62 columns since we have 63 rows, the data is still clustering around treatments, so we can still run the knn
#solution sequential pca's pick out top 4 proteins that align with Comp 1 create new model, measure accuracy, use string db

# columns 63-124
subset.y <- subset.df[,63:124]
subset.y[] <- lapply(subset.y,as.numeric)
subset.y

principal_components <- princomp(subset.y, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)

## Columns 125-186
subset.z <- subset.df[,125:186]
subset.z[] <- lapply(subset.z,as.numeric)
subset.z

principal_components <- princomp(subset.z, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)
#columns 187 to 248

subset.a <- subset.df[,187:248]
subset.a[] <- lapply(subset.a,as.numeric)
subset.a

principal_components <- princomp(subset.a, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)

# Columns 249-310

subset.b <- subset.df[,249:310]
subset.b[] <- lapply(subset.b,as.numeric)
subset.b

principal_components <- princomp(subset.b, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)
#Columns 311-372

subset.c <- subset.df[,311:372]
subset.c[] <- lapply(subset.c,as.numeric)
subset.c

principal_components <- princomp(subset.c, cor = TRUE, score = TRUE)

summary(principal_components)


# using the plot() function, we can plot the principal components.
plot(principal_components)

# plotting the principal_components using the a line in plot() functions 
plot(principal_components, type = "l")

# using rhw biplot() function we can plot the components
biplot(principal_components)

## using autoplot() function to plot the components
autoplot(principal_components, data = subset_full.K, colour = 'Treatment',
         loadings = TRUE, loadings.colour = 'blue',
         loadings.label = TRUE, loadings.label.size = 3)
#now we create a new subset that just has the proteins that align with the pca's and the treatments

subset_pca.sum <- subset_full.K

# Define the names of the columns you want in the subset
desired_columns <- c("Treatment", "P69566", "O88508", "Q9DBE9", "Q922K7", "Q3U6N9", "Q8C0D0", "Q8VDV8", "Q4PZA2", "Q6ZQ82", "Q9QXL1", "F7BJB9", "Q9D428", "Q6WKZ8", "Q9EPE9", "Q9EPL0", "Q9CSU0", "Q61735", "Q8CI32", "P61080", "P51829", "Q9Z0M6", "P52482", "P56873", "Q60876")  # Replace with your desired column names

# Create a subset using the column names
subset_pca.sum <- subset_pca.sum[, desired_columns, drop = FALSE]  # `drop = FALSE` keeps the subset as a data frame even if it has one column

# Inspect the result
dim(subset_pca.sum)  # Check the dimensions of the subset

# we have created a subset from the top four comp 1 aligned proteins from each of our pca's, lets put them through knn 


n.sum = nrow(subset_pca.sum)

## training set indexes
train.indexes.sum <- sample(n.sum,n.sum*.7)

## create training/test sets
sample.train.sum <-subset_pca.sum[train.indexes.sum,]
sample.test.sum <-subset_pca.sum[-train.indexes.sum,]

sqrt(44)
k=7
KNNpred <- knn(train = sample.train.sum[2:25], test = sample.test.sum[2:25], cl = sample.train.sum$Treatment, k = k)

## evaluate
contingency.table <- table(Actual=KNNpred, Predicted = sample.test.sum$Treatment, dnn=list('predicted','actual'))

print(contingency.table)

contingency.matrix = as.matrix(contingency.table)

sum(diag(contingency.matrix))/length(sample.test.sum$Treatment)

## run text with multiple k values
accuracy <- c()
ks <- seq(1,7,1)

for (k in ks) {
  
  KNNpred <- knn(train = sample.train.sum[2:25], test = sample.test.sum[2:25], cl = sample.train.sum$Treatment, k = k)
  cm = as.matrix(table(Actual=KNNpred, Predicted = sample.test.sum$Treatment, dnn=list('predicted','actual')))
  
  accuracy <- c(accuracy,sum(diag(cm))/length(sample.test.sum$Treatment)) 
  
}

plot(ks,accuracy,type = "b")

#now test for new model on subset of original full.K

KNNpred.sum <- knn(train = sample.train.sum[2:25], test = sample.testk[1001:1024], cl = sample.train.sum$Treatment, k = k)

## evaluate
contingency.table <- table(Actual=KNNpred.sum, Predicted = sample.testk$Treatment, dnn=list('predicted','actual'))

print(contingency.table)

contingency.matrix = as.matrix(contingency.table)

sum(diag(contingency.matrix))/length(sample.test.sum$Treatment)

## applying PCA based model to new subset of full.k (all proteins and treatment) decreased accuracy from 80-90% to 21% (not as accurate)

## run text with multiple k values
accuracy <- c()
ks <- seq(1,7,1)

for (k in ks) {
  
  KNNpred2.sum <- knn(train = sample.train.sum[2:25], test = sample.testk[1001:1024], cl = sample.train.sum$Treatment, k = k)
  cm = as.matrix(table(Actual=KNNpred2.sum, Predicted = sample.test.sum$Treatment, dnn=list('predicted','actual')))
  
  accuracy <- c(accuracy,sum(diag(cm))/length(sample.test.sum$Treatment)) 
  
}

plot(ks,accuracy,type = "b")
